export interface Pricelist {
}
