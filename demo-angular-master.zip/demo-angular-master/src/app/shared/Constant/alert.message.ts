export const message: any = {
    ChangePasswordError: 'Your password is not updated. Please try again.',
    ChangePasswordSuccess: 'Your password has been changed Successfully',
    ForgetPasswordSuccess: 'Please check your inbox for reset password link',
    ForgetPasswordUnsuccess: 'Invalid email',
    LoginUnsuccess: 'Invalid email or password',
    RegistrationSuccess: 'Please check your email for verification link',
    ParserUploadSuccess: 'File Upload Successfully',
    Error: 'Something went wrong. please try again',
    ParserFileNotChoose: 'File Not Choose',
    RegistrationDetailsSave: 'your detail submitted successfully. Please login to cared',
    ConfirmBudgetError: 'You have unconfirmed budget in your list, please confirmed it'
};

