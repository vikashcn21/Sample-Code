export interface Response {
    data: any;
    message: string;
    statusCode: number;
}
