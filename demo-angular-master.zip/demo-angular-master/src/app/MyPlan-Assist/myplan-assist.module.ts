import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyplanAssistRoutingModule } from './myplan-assist-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MyplanAssistRoutingModule
  ]
})
export class MyplanAssistModule { }
