import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-token-verify',
  templateUrl: './token-verify.component.html',
  styleUrls: ['./token-verify.component.scss']
})
export class TokenVerifyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
