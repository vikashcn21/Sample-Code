export interface Planparser {
}
