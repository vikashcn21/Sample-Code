import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-funded-goals',
  templateUrl: './plan-funded-goals.component.html',
  styleUrls: ['./plan-funded-goals.component.css']
})
export class PlanFundedGoalsComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {

  }

}
