import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-funded',
  templateUrl: './plan-funded.component.html',
  styleUrls: ['./plan-funded.component.css']
})
export class PlanFundedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
