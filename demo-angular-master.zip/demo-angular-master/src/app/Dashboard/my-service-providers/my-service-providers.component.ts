import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-service-providers',
  templateUrl: './my-service-providers.component.html',
  styleUrls: ['./my-service-providers.component.scss']
})
export class MyServiceProvidersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
