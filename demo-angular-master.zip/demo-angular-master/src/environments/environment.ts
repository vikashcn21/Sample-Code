// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
export const environment = {
  production: false,
  TRACKING_ID: 'UA-197134759-1',
  BASE_URL_POST: '',
  BASE_URL_GET: '',
  SEARVICE_PROVIDER: '',
  BASE_URL_PROFILE: '',
  BASE_URL_AUTHENTICATION: '',
  // BASE_URL_AUTHENTICATION: '',
  BASE_URL_AUTH_SERVER: '',
  PARSING_TYPE: 'Text',
  // BASE_URL: '',
  isVisibleOnProduction: 1,
  firebaseConfig: {
    apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
  measurementId: ''
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
