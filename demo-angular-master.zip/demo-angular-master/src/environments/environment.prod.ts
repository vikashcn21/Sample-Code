export const environment = {
  production: true,
  BASE_URL_POST: '',
  BASE_URL_GET: '',
  SEARVICE_PROVIDER: '',
  BASE_URL_PROFILE: '',
  BASE_URL_AUTHENTICATION: '',
  BASE_URL_AUTH_SERVER: '',
  PARSING_TYPE: 'Text',
  isVisibleOnProduction: 0,
};
